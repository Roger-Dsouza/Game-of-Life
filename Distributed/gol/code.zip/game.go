package gol

import (
	"uk.ac.bris.cs/gameoflife/util"
	"net"
	"net/rpc"
	"flag"

)

//Flag 0 for width, 1 for height.
func isBound(lo int, hi int, val int,maxVal int) int {
	if (val >= lo && val <=hi){
		return val
	} else if (val<lo) {
		return (maxVal-1)
		
	}else{
		return maxVal-val
	}

}

//Struct for the Game of Life Method.
type cellCalc struct {}

func checkCell(world [][]byte,h int,w int) int{
	if (h!=-1 && w!=-1){
		if (world[h][w]==255){

			return 1;
		}else{
			return 0;
		}
	}else{
		return 0
	}



}

func singleCalc(c compactType,r *compactType) (err error){
	calculateRows(c.p,c.src,c.dst,0,c.p.ImageHeight)
	r.src=c.dst
	r.dst=c.src
	r.p=c.p
	

	
	return
}


func calculateRows(p Params, world [][]byte,dst [][]byte,startRow int,endRow int)(err error) {
	var width int = p.ImageWidth
	var height int = p.ImageHeight

    for h := startRow; h < endRow; h++ {
        for w:= 0; w < width; w++ {
            var activeCells int = 0
            var val byte = world[h][w]


			var low int = isBound(0, width-1, w-1,width)
			var loh int = isBound(0, height-1, h-1,height)

			var hiw int = isBound(0, width-1, w+1,width)
			var hih int = isBound(0, height-1, h+1,height)



            activeCells+=(checkCell(world,loh,low)+checkCell(world,hih,hiw))
			activeCells+=(checkCell(world,loh,w)+checkCell(world,hih,w))
			activeCells+=(checkCell(world,h,low)+checkCell(world,h,hiw))
			activeCells+=(checkCell(world,loh,hiw)+checkCell(world,hih,low))
			
			

			switch val {
            case 0:
				if activeCells == 3 {
					dst[h][w] = 255
					
				}else{
					dst[h][w] = 0
				}

			case 255:
				if activeCells < 2 || activeCells > 3 {
					dst[h][w] = 0
					

				}else{
					dst[h][w]=255
				}
			}

		}

	}
	return
}



func calculateAliveCells(p Params, world [][]byte) []util.Cell {
	var active []util.Cell
	var width int = p.ImageWidth
	var height int = p.ImageHeight

	for h := 0; h < height; h++ {
		for w := 0; w < width; w++ {
			if world[h][w] == 255 {
				c := util.Cell{Y: h, X: w}
				active = append(active, c)

			}

		}

	}
	return active
}


func aliveCellCount(p Params, world [][]byte) int {
	total:=0
	var width int = p.ImageWidth
	var height int = p.ImageHeight

	for h := 0; h < height; h++ {
		for w := 0; w < width; w++ {
			if world[h][w] == 255 {
				total++;

			}

		}

	}
	return total
}


func main(){
	start:=flag.String("port","8030","Listening port.")
	flag.Parse()
	rpc.Register(&cellCalc{})
	listener,err:=net.Listen("tcp",":"+*start)

	if (err!=nil){
		panic(err)
	}

	defer listener.Close()
	rpc.Accept(listener)

}